// pcm-tsx-win.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "../pcm-tsx.cpp"
